module com.premaseem.dry {
    requires mongo.java.driver;
}