module com.premaesem.wet {
    exports com.premaseem;
    requires mongo.java.driver;
}