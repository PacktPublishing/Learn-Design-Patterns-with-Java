# Video 1.6: Are design patterns different for different languages
Design pattern is language independent and since they are guide lines to the design solution they can be implemented with any programming language, however implementation details might differ.
In the code base, factory pattern is implemented in Java 9 and Python. 

# DesignPatternsJava9
This repo consists Gang of Four Design patterns code on Java 9. Each branch in the repository has code of 1 design pattern. Switch repository to try out different design patterns.

