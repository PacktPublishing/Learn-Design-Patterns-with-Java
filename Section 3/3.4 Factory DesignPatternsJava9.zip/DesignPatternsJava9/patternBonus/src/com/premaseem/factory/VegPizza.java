package com.premaseem.factory;

public class VegPizza implements PizzaBase {

	@Override
    public double getCost() {
	    // TODO Auto-generated method stub
	    return 10;
    }

	@Override
    public String getDescription() {
	    // TODO Auto-generated method stub
	    return "Veg Pizza";
    }

}
