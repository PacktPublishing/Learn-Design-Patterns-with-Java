package com.premaseem.factory;

public interface PizzaBase {
	
	double getCost();
	String getDescription();

}
