package com.premaseem.phones;

/*
@author: Aseem Jain
@title: Design Patterns with Java 9
@link: https://premaseem.wordpress.com/category/computers/design-patterns/
*/
public class GooglePhone {

    public Integer getSoundOutput(){

        return 1001010101;
    }
}
